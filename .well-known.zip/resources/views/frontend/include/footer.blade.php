@php
$contact = App\Models\Contact::get()->first();
@endphp

<!-- ======= Footer ======= -->
<footer style="background-color: #000;">
    <div class="footer-top pt-5">
        <div class="container text-white">
            <div class="row">
                <div class="col">
                    <div class="footer-logo">
                        <img src="{{ asset('frontend/assets/img/logo/logo-white.png')}}" class="img-fluid">
                    </div>
                </div>
                <div class="col">
                    <div class="quick_link">
                        <h2><strong>Company</strong></h2>
                        <ul>
                            <li><a href="{{ route('about') }}">About us</a></li>
                            <li><a href="{{ route('contact') }}">Contact Us</a></li>
                            <li><a href="{{ route('terms') }}">Term and conditions</a></li>
                            <li><a href="{{ route('career') }}">Career</a></li>
                            <li><a href="{{ route('privacy') }}">Privacy policy</a></li>
                            <li><a href="{{ route('cookies') }}">Cookies policy</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col">
                    <div class="career">
                        <h2><strong>Help & Support</strong></h2>
                        <div class="email">
                            <a href="mailto:info@worldwidesvc.com" style="color: #fff;">info@worldwidesvc.com</a>
                        <a href="mailto:enquiries@worldwidesvc.com" style="color: #fff;">enquiries@worldwidesvc.com</a>
                        </div>
                        <h2><strong>Office</strong></h2>
                        <a href="tel:+4402088557777" style="color: #fff;">+44 (0) 20 8855 7777</a>
                    </div>
                </div>
                <div class="col-auto">
                    <div class="follow_us">
                        <div class="social-box">
                            <h2><strong>Follow US</strong></h2>
                        </div>
                        <div class="social-icon">
                            <a href="{{ $contact->facebook }}" class="facebook p-1"><img
                                    src="{{ asset('frontend/assets/img/social/facebook.png')}}" alt=""></a>
                            <a href="{{ $contact->twitter }}" class="twitter p-1"><img
                                    src="{{ asset('frontend/assets/img/social/twitter.png')}}" alt=""></a>
                            <a href="{{ $contact->linkedin }}" class="linkedin p-1"><img
                                    src="{{ asset('frontend/assets/img/social/linkedin.png') }}" alt=""></a>
                            <a href="{{ $contact->youtube }}" class="google-plus p-1"><img
                                    src="{{ asset('frontend/assets/img/social/youtube.png') }}" alt=""></a>
                            <a href="{{ $contact->instagram }}" class="instagram p-1"><img
                                    src="{{ asset('frontend/assets/img/social/instagram.png') }}" alt=""></a>
                        </div>
                        <div class="time">
                            <span> Mon to Fri -9am to 5pm</span>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="f-content">
                        <p style="font-size: 12px; line-height:15px; text-align: justify;">Worldwide West 2 East Services Limited, a company
                        incorporated in England with registered number 07684314 whose registered address is at 92a
                        Plumstead High Street, London, SE18 1LS is authorised by the Financial Conduct Authority (“FCA”)
                        under the Payment Services Regulations 2009 (SI 2009 No. 209) (the “Regulations”) for the
                        provision of payment services with FCA register number 563795 and trades under the name
                        'Worldwide Services'</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-bottom" id="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright text-center">
                        <p>Copyright &copy; 2022 <strong><span>Worldwide</span></strong>. All Rights Reserved</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<style type="text/css">
    .quick_link a {
        color: #fff;
    }

</style>
<!-- End Footer -->
