@extends('frontend.master')
@section('content')
@section('title', 'Career')
@section('career', 'active')


<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="career-banner">
                <img src="{{ asset('frontend/assets/img/banner/about-us-web.png')}}" alt="" class="img-fluid">
            </div>
        </div>
    </div>
</div>

<main id="main">

    <div class="container">
        <div class="career_content">
            <div class="row">
                <div class="col-md-8">
                    <div class='designation'>
{{--                        <h2 class="my-4">Designation</h2>--}}
                            <h2 class="career_title my-4">COMPLIANCE OFFICER</h2>
                            <div class="career_description">
                                <p>We are looking for a Compliance Officer to keep our organization with a strong
                                    compliance department and continuous with a perfect internal and external
                                    regulations.</p>
                                <p>A Successful Compliance Officer is proficient with local and international laws,
                                    standards and the auditing techniques and procedures relating to their
                                    organization.</p>
                            </div>
                    </div>
                    <div class="offering my-5">
                        <h6 class="career_title">What are we offering?</h6>
                        <div class="career_description">
                            <ul class="offer_details">
                                <li>
                                    <span>Salary: </span> &nbsp; &nbsp; £25,000 to £30,000 per year (depending on the experience
                                    and background)
                                </li>
                                <li>
                                    <span>Hours: </span> &nbsp; &nbsp; Full time
                                </li>
                                <li>
                                    <span>Holidays: </span> &nbsp; &nbsp; 28 days including bank holidays
                                </li>
                                <li>
                                    <span>Job type: </span> &nbsp; &nbsp; Permanent
                                </li>
                                <li>
                                    <span>Closing date: </span> &nbsp; &nbsp; 13 August 2022
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="accepting mb-5">
                        <h6 class="career_title">Accepting you, for you.</h6>
                        <div class="career_description">
                            <p>
                                We want you to feel accepted for who you are and to feel safe, valued and to help us
                                build a culture of true belonging. Worldwide is proud to be an equal opportunity
                                employer and we take affirmative action to create a more inclusive and equitable world
                                of work. We are committed to equal employment opportunities regardless of age,
                                disability, gender identity, marital status, race, ethnicity, faith or belief, sexual
                                orientation, socioeconomic background, Veteran status or whether you’re pregnant or on
                                family leave.
                            </p>
                        </div>
                    </div>
                    <div class="job_descriton">
                        <h6 class="career_title">Job Description</h6>
                        <div class="career_description">
                            <ul>
                                <li> Performing routine risk assessments to help organizations understand compliance
                                    risk, scope and significance</li>
                                <li>Monitoring the organization's compliance with regulations and internal policies to
                                    ensure they are up to date with the relevant laws</li>
                                <li>Educating employees on compliance regulations and the impact of non-compliance on
                                    the organization</li>
                                <li>Recording their findings properly and following up with management to ensure the
                                    issues are rectified</li>
                            </ul>
                        </div>
                    </div>
                    <div class="required my-5">
                        <h6 class="career_title">Required Skills</h6>
                        <div class="career_description">
                            <ul>
                                <li> Critical problem-solving skills and the ability to make informed decisions quickly
                                </li>
                                <li>Excellent analytical skills and the ability to interpret information rapidly</li>
                                <li>Attention to details and the ability to comprehend information thoroughly and
                                    understand its significance</li>
                                <li>Excellent leadership and management skills</li>
                                <li>High ethical standards</li>
                                <li>Excellent verbal and written communication skills</li>
                                <li>Good interpersonal and conflict management skills</li>
                                <li>Excellent presentation and public speaking skills</li>
                                <li>Reviewing marketing materials, websites, and presentations to ensure compliance with
                                    regulations</li>
                                <li>Assisting in the gathering of information internally in response to requests by
                                    regulatory organizations</li>
                                <li>Performing administrative tasks such as file creation and maintaining files of
                                    ongoing projects</li>
                                <li>Collaborating with management from other departments to ensure compliance and
                                    investigating irregularities</li>
                            </ul>
                        </div>
                        <p style="color:red;">To Apply Please Submit Your CV with Cover Letter to <a href="mailto:hr@worldwidesvc.com" style="color:#52B2E3;">hr@worldwidesvc.com</a> </p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="text-center my-5">
                        <a href="{{ url('/') }}"><img src="{{ asset('frontend/assets/img/logo/logo.png')}}" alt=""
                                class="img-fluid"></a>
                    </div>

                    <div class="why_chose_us">
                        <h6 class="career_title">Why choose us?</h6>
                        <div class="career_description">
                            <p>An essential component of excellent customer service is listening to the customers’
                                needs.
                                You hear their concerns. You
                                try to understand where they are coming from. You leverage emotional intelligence to
                                show
                                empathy.</p>
                            <p>Now, imagine actively doing all of that with coworkers. Think how much more likely
                                your team
                                is to pull in the same
                                direction and applaud each other’s successes. Better listening can bring greater
                                success
                                overall.</p>
                            <p>This is our policy in Worldwide: <strong>“We are each other's customers”</strong>. In
                                Worldwide we are treating colleagues as customers,
                                and it dramatically enhance the culture in our work environment. When employees all
                                treat
                                each other with respect and
                                look for ways to help one another, the business benefits.</p>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>

</main>

@endsection
