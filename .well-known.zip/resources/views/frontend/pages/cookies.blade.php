@extends('frontend.master')
@section('content')
@section('title','Cookies Policy')


  <section>
    <div class="container">
      <div class="col-md-12">
          <h1 align="right" class="text-white "><b>Cookies Policy</b></h1>
          <hr class="text-white" style="height:3px">
      </div>
    </div>
    
  </section>

  <main id="main">


    <!-- ======= Featured Services Section ======= -->
    <section id="featured-services" class="featured-services">
      <div class="container">
        <div class="row about">
          <div class="col-md-12 my-5 text-white" style="color: #fff !importent">
            {!! $cookies->description !!}
          </div>
          
        </div>
       

      </div>
    </section><!-- End Featured Services Section -->

  </main><!-- End #main -->
@endsection