
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','Contact'); ?>
<?php $__env->startSection('contact', 'active'); ?>

  <!-- ======= Hero Section ======= -->
  <section id="contact-first">
    <div class="container">
      <div class="get_in_touch text-center">
        <h1>Get In Touch</h1>
        <p>Please provide some information to get started.</p>
      </div>
    </div>
    
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact" style="padding:0px">
      <div class="container">

        <div class="row">

          <div class="col-lg-6 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <p><?php echo e($contact->description); ?></p>
              </div>

              <div class="email">
                <h4>Office</h4>
                <p class="pt-2"><a href="" style="color: #fff;text-decoration: underline;"><?php echo e($contact->address); ?></a></p>
                <p class="time"><span><?php echo e($contact->office_hours); ?></span> </p>
              </div>

              <div class="phone pt-3">
                <div class="row">
                  <div class="col-md-6">
                    <h4 class="pb-4">Call US</h4>
                    <a href="tel:<?php echo e($contact->phone_one); ?>"><?php echo e($contact->phone_one); ?></a> <br>
                    <a href="tel:<?php echo e($contact->phone_two); ?>"><?php echo e($contact->phone_two); ?></a>
                  </div>
                  <div class="col-md-6">
                    <h4>Email US</h4><br>
                    <a href="mailto:<?php echo e($contact->email_one); ?>"><?php echo e($contact->email_one); ?></a>
                  </div>
                </div>
              </div>

            </div>

          </div>
          <div class="col-lg-6 mt-5 mt-lg-0 d-flex align-items-stretch">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="form-group mt-3">
                  <input type="email" class="form-control" name="email" placeholder="Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="full_name" placeholder="Full Name" required>
              </div>
              <div class="form-group mt-3">
                <label for="name" class="mb-3 text-white">How Can we help you?</label>
                <textarea class="form-control" name="message" rows="5" required placeholder="Type your full message here"></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div align="right"><button type="submit">Submit</button></div>
            </form>
          </div>


        </div>

      </div>
    </section><!-- End Contact Section -->

    <section style="padding-bottom:0px; margin-bottom: -6px;">
      <div class="container-fluid">
        <div class="row clearfix">
          <div class="col-md-12 p-0">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2484.36261867371!2d0.08744381591224921!3d51.48821281992663!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47d8a8cc73aae0cd%3A0xa0ebb28a923cf32d!2s92a%20Plumstead%20High%20St%2C%20London%20SE18%201SL%2C%20UK!5e0!3m2!1sen!2sbd!4v1650344758723!5m2!1sen!2sbd" width="100%" height="450px" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" ></iframe>
          </div>
        </div>
      </div>
    </section>

  </main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\worldwide\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>