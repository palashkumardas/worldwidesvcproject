<?php echo e($slot); ?>

<?php /**PATH /home/u17shag/public_html/test/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>