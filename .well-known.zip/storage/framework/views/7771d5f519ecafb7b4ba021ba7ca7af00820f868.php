[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH E:\worldwide\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>