
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'About'); ?>
<?php $__env->startSection('about', 'active'); ?>

  <!-- ======= Hero Section ======= -->
  <div id="banner">
    <div class="container-fluid p-0">
      <div class="d-none d-md-block">
        <img src="<?php echo e(asset('frontend/assets/img/banner/about-us-web.png')); ?>" class="img-fluid">
      </div>
      <div class="d-md-none d-sm-block">
        <img src="<?php echo e(asset('frontend/assets/img/banner/about-us-mobile.png')); ?>" class="img-fluid">
      </div>
    </div>
    
  </div><!-- End Hero -->

  <main id="main">


    <!-- ======= Featured Services Section ======= -->
    <section id="featured-services" class="featured-services">
      <div class="container">
        <div class="row about">
          <div class="col-md-12 my-5 text-white">
            <!-- <p><?php echo $about->description; ?></p> -->
            <p>Worldwide West 2 East Services Limited, trading as WORLDWIDE SERVICES, is a financial services company that aims to facilitate the financial support of friends and families across the world. Established in 2011, we are a UK-based money transfer remittance service provider. The company's Financial Conduct Authority Reference number is 563795 and is registered with HMRC (MLR – 57885). Our registered address is at 92A Plumstead High Street, London, SE18 1SL.</p><p>
The necessity of money transfer stretches far beyond the essence of a transfer of funds. It plays a pivotal role in the lives of our loved ones, wherever they may be in the world, facilitating a better livelihood for those we hold dear to us. In this globalised world, we want to support the growth of all countries, bringing the interconnected countries closer together and essentially, we support small business of migrants providing a digital transformation to keep their business running and growing. WORLDWIDE SERVICES strives to ensure you receive the fairest service, offering market competitive rates and charges, alongside consistent support availability. With technology always changing around us, it is important to us to offer the different payment methods, so that the agents can continue to offer the service with liability to their customers and their loved ones to access their funds with ease. WORLDWIDE SERVICES feels privileged to play a part in supporting and affecting so many lives across the globe and for that reason our slogan is what it is because we indeed provide to our clients “integrity, accessibility and simplicity"</p>
          </div>
          
        </div>
       

      </div>
    </section><!-- End Featured Services Section -->

  </main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\worldwide\resources\views/frontend/pages/about.blade.php ENDPATH**/ ?>