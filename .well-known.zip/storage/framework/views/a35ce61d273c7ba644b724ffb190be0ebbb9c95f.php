<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($email_data['first_name']); ?> <?php echo e($email_data['last_name']); ?> 



<p>Email: <?php echo e($email_data['email']); ?></p>
<p>Phone: <?php echo e($email_data['phone']); ?></p>
<p>Contact Preferences: <?php echo e($email_data['contact_preferences']); ?></p>


Address: <?php echo e($email_data['address']); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH E:\worldwide\resources\views/emails/received_mail.blade.php ENDPATH**/ ?>