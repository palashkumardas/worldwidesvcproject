
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','Service'); ?>
<?php $__env->startSection('services','active'); ?>

  <main id="main">

    <!-- ======= services Section ======= -->
    <section class="service-first">
      <div class="container">
        <div class="col-md-12">
          <h1 align="right" class="text-white "><b>Our Services</b></h1>
          <hr class="text-white" style="height:3px">
        </div>
        <div class="col-md-12">
          <div class="quote">
            <pre><img src="<?php echo e(asset('frontend/assets/img/quote1.svg')); ?>" alt="">
              How we make your
              business to have a
              Digital Transformation <img src="<?php echo e(asset('frontend/assets/img/quote2.svg')); ?>" alt="">
              </pre>
          </div>

          <p>We provide you all the tools and facilites to start or to grow your money transfer busniess. If you already
            have a shop we will provide to you 3 channels to develop your business: a web platform/card machine to place
            remittances for your customers , a website and IOS/ANDROID APP to your customers place remittances
            themselves. All 3 chanells are white labeled and we will add your logo and your colour to help your customer
            to identify yourself and to keep his/her loyalty to you.
          </p>
          <p>
            We also provide you a portal to check all transactions placed in all 3 chanels and a dedicated bank account
            under your name where you will be able to see all your customers deposits and card payments what will help
            us to make all remittances to be paid quickly and smoothly.
          </p>
        </div>
      </div>

    </section><!-- End services -->

    <section class="service-second">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div class="card border-0 bg-transparent">
              <div class="card-header border-0 bg-transparent service-card">

                <div class="service_img">
                  <img src="<?php echo e(asset('frontend/assets/img/Laptop.png')); ?>" class="img-fluid">
                </div>
              </div>
              <div class="card-body">
                <h5>Website white labaled with your logo</h5>
                <h1>We will provide your business website with
                  your logo.</h1>
                <p>Need your business website to be designed by us? We will be there with our best IT team.</p>
              </div>
            </div>


          </div>
          <div class="col-md-4">
            <div class="card border-0 bg-transparent">
              <div class="card-header border-0 bg-transparent service-card text-center">
                <div class="service_img">
                <img src="<?php echo e(asset('frontend/assets/img/Mobile.png')); ?>" class="img-fluid" style="height:300px;">
                </div>
              </div>
              <div class="card-body">
                <h5>IOS/ Android app white labaled with your logo</h5>
                <h1>We will provide interactive ios/android app with your business logo.</h1>
                <p>Our best IT team will be there to give you quality & smooth app to run your business and easily get
                  connected with customers.</p>
              </div>
            </div>

          </div>



          <div class="col-md-4">
            <div class="card border-0 bg-transparent">
              <div class="card-header border-0 bg-transparent service-card">
                <div class="service_img">
                  <img src="<?php echo e(asset('frontend/assets/img/Shop.png')); ?>" class="img-fluid">
                </div>
                
              </div>
              <div class="card-body">
                <h5>Agent Portal, Face to Face terminal Card</h5>
                <h1>Get your agent portal access easy to run your business efficiently.</h1>
                <p>An efficient portal will help you to track your database easily, get your data store easily.An
                  efficient portal will help you to track your database easily, get your data store easily.</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>

    <section class="service-third">

      <div class="container">
        <div class="row">

          <div class="col-md-12">
            <div class="quote">
              <pre><img src="<?php echo e(asset('frontend/assets/img/quote1.svg')); ?>" alt="">
                How we gonna pay you
                and give you
               <strong class="client">Support</strong> for that <img src="<?php echo e(asset('frontend/assets/img/quote2.svg')); ?>" alt="">
                </pre>
            </div>
            <p>
              We will pay you comission for each remittance that you or your customer do. We will also provide you a
              strong support team for any inquiry making your life easier and your business solid. Our team are availabe
              18 hours a day from monday to saturday and 6 hours on sundays and bank holidays in the UK.
            </p>
            <p>
              We will also support and help you in marketing. Our IT and Marketing team have a dedicated social media
              developer who will help you to boost your business. We will also suggest promotions from time to time and
              if you accept the promotion we will promote it for you digitally.
            </p>
          </div>
        </div>
      </div>
    </section>

    <section id="about" class="home-about mt-3">
      <div class="container">

        <div class="row">
          <div class="col-lg-6 ">
            <h1 class="text-white">Become An Agent</h1>
            <p>
              Joining Worldwide network could offer your business significant advantage and give you the growth you’ve
              been seeking. Becoming an Agent is a simple and easy process and we offer you constant support every step
              of the way.
            </p>
            <button>Register today</button>
          </div>
          <div class="col-lg-6 pt-4 ">
            <div class="content">
              <h1>Don’t Lose time! Join Us and we will help your business to become Digital powered by
                WORLDWIDE SERVICES</h1>
            </div>
          </div>
        </div>

      </div>
    </section>
    <section class="service-four">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="quote">
              <pre><img src="<?php echo e(asset('frontend/assets/img/quote1.svg')); ?>" alt="">
              Get to know what our
              <strong class="client">Client</strong> says for us <img src="<?php echo e(asset('frontend/assets/img/quote2.svg')); ?>" alt="">
              </pre>
            </div>
          </div>

          <!-- Testimonial Section -->
          <div class="col-md-12 mb-5">
            <div class="testimonial-slider swiper">
              <div class="swiper-wrapper align-items-center">
                <div class="swiper-slide">
                  <div class="review">
                    <div class="row">
                      <div class="col-md-2">
                        <img src="<?php echo e(asset('frontend/assets/img/demo.png')); ?>" class="img-fluid">
                      </div>
                      <div class="col-md-10">
                        <h2>Sunnah Money Transfer</h2>
                        <h5 style="color:  #676767"></h5>
                        <img src="<?php echo e(asset('frontend/assets/img/star.svg')); ?>" class="img-fluid">
                      </div>
                      <div>
                        <p>
                          As always a brilliant seamless service from Worldwide Services. It is the most trustful, fastest, easiest to use and cheapest service to transfer money. I am very glad to have this platform in my region. Thank you very much for the quality service.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="review">
                    <div class="row">
                      <div class="col-md-2">
                        <img src="<?php echo e(asset('frontend/assets/img/demo.png')); ?>" class="img-fluid">
                      </div>
                      <div class="col-md-10">
                        <h2>Barakah Money transfer</h2>
                        <h5 style="color:  #676767"></h5>
                        <img src="<?php echo e(asset('frontend/assets/img/star.svg')); ?>" class="img-fluid">
                      </div>
                      <div>
                        <p>
                          Simple user-friendly interface: this platform is simple to use with every feature and functionality within reach. I am very satisfied with the Worldwide services which informs me on every step.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="review">
                    <div class="row">
                      <div class="col-md-2">
                        <img src="<?php echo e(asset('frontend/assets/img/demo.png')); ?>" class="img-fluid">
                      </div>
                      <div class="col-md-10">
                        <h2>Madina Money Transfer</h2>
                        <h5 style="color:  #676767"></h5>
                        <img src="<?php echo e(asset('frontend/assets/img/star.svg')); ?>" class="img-fluid">
                      </div>
                      <div>
                        <p>
                          It has saved a lot of money as the fees are very low and what you pay is transparent at the time of the transaction or conversion. Of particular interest and concern to me is the transparent manner in which it operates. I highly recommend you to use Worldwide Services.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="review">
                    <div class="row">
                      <div class="col-md-2">
                        <img src="<?php echo e(asset('frontend/assets/img/demo.png')); ?>" class="img-fluid">
                      </div>
                      <div class="col-md-10">
                        <h2>SOS remit</h2>
                        <h5 style="color:  #676767"></h5>
                        <img src="<?php echo e(asset('frontend/assets/img/star.svg')); ?>" class="img-fluid">
                      </div>
                      <div>
                        <p>
                          The fees that are charged by Worldwide Services are extremely competitive and its cashout option is very useful, specially if you travel and deal with several currency at the same time. It's become the bank I use the most.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-pagination"></div>
            </div>


            <!-- <div class="row">
              <div class="col-md-5 review">
                <div class="row">
                  <div class="col-md-2">
                    <img src="<?php echo e(asset('frontend/assets/img/person.png')); ?>" class="img-fluid">
                  </div>
                  <div class="col-md-10">
                    <h2>Selina Mahmud</h2>
                    <h5 style="color:  #676767">Money transfer agent</h5>
                    <img src="<?php echo e(asset('frontend/assets/img/star.svg')); ?>" class="img-fluid">
                  </div>
                  <div>
                    <p>
                      Great service, I liked the way they approached and get all things done.
                      Great service, I liked the way they approached and get all things done.
                      Great service, I liked the way they approached and get all things done.
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-md-5 review">
                <div class="row">
                  <div class="col-md-2">
                    <img src="<?php echo e(asset('frontend/assets/img/person.png')); ?>" class="img-fluid">
                  </div>
                  <div class="col-md-10">
                    <h2>Selina Mahmud</h2>
                    <h5 style="color:#676767">Money transfer agent</h5>
                    <img src="<?php echo e(asset('frontend/assets/img/star.svg')); ?>" class="img-fluid">
                  </div>
                  <div>
                    <p>
                      Great service, I liked the way they approached and get all things done.
                      Great service, I liked the way they approached and get all things done.
                      Great service, I liked the way they approached and get all things done.
                    </p>
                  </div>
                </div>
              </div>

            </div> -->
          </div>
          <div class="col-md-12">
            <div class="quote">
              <pre><img src="<?php echo e(asset('frontend/assets/img/quote1.svg')); ?>" alt="">
              We have <strong style="font-size: 60px;line-height: 60px;">4</strong> different
              packs to offer you <img src="<?php echo e(asset('frontend/assets/img/quote2.svg')); ?>" alt="">
              </pre>
            </div>
          </div>


        </div>
        <!-- --------------- Pack Section ------------------------- -->
        <div class="row">

          <div class="col-md-6">
            <div class="packs">
              <div class="packs-top">
                <img src="<?php echo e(asset('frontend/assets/img/pack1.png')); ?>" class="img-fluid">
                <h4>3 channels white labelled pack </h4>
              </div>
              <div class="text-end">
                <p>You will have the web platform in your shop with card terminal to place transactions on your
                  customers behalf, a website and app white labelled with your logo and colours</p>
                <button>Try This Pack</button>
              </div>
            </div>
          </div>

          <div class="col-md-6">
            <div class="packs">
              <div class="packs-top">
                <img src="<?php echo e(asset('frontend/assets/img/pack2.png')); ?>" class="img-fluid">
                <h4>3 channels customized pack </h4>
              </div>
              <div class="text-end">
                <p>You will have the web platform in your shop with card terminal to place transactions on your
                  customers behalf, a website and app white labelled with your logo and customized colours plus
                  pictures, testimonials and history in your website/app.</p>
                <button class="">Try This Pack</button>
              </div>
            </div>
          </div>

          <div class="col-md-6">
            <div class="packs">
              <div class="packs-top">
                <img src="<?php echo e(asset('frontend/assets/img/pack3.png')); ?>" class="img-fluid">
                <h4>2 channels white labelled pack</h4>
              </div>
              <div class="text-end">
                <p>You will have a website and app white labelled with your logo and colours</p>
                <button class="">Try This Pack</button>
              </div>
            </div>
          </div>

          <div class="col-md-6">
            <div class="packs">
              <div class="packs-top">
                <img src="<?php echo e(asset('frontend/assets/img/pack4.png')); ?>" class="img-fluid">
                <h4>2 Channels customized pack </h4>
              </div>
              <div class="text-end">
                <p>You will a website and app white labelled with your logo and customized colours plus pictures,
                  testimonials and history in your website/app.</p>
                <button class="">Try This Pack</button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>


    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container">

        <div class="row">
          <div class="col-lg-9 text-center text-lg-start">
            <h3>Consulting for taking our agentship</h3>
            <p>Consult us now!</p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle bg-white text-dark" href="#">Contact Us</a>
          </div>
        </div>

      </div>
    </section><!-- End Cta Section -->

  </main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\worldwide\resources\views/frontend/pages/services.blade.php ENDPATH**/ ?>