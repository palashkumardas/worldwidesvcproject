<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/u17shag/public_html/test/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>