<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="http://worldwidesvc.com/images/icons/logo-vendor.png" class="logo" alt="Worldwide">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH /home/u17shag/public_html/test/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>