
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('home', 'active'); ?>

 <!-- ======= Hero Section ======= -->
<!--  <section id="hero" class="p-0">
    <div class="container-fluid">
      <div class="banner_img">
        <img src="<?php echo e(asset('frontend/assets/img/homepage.png')); ?>" class="img-fluid" style="height: 550px; width:100%; background-repeat: no-repeat; background-size: cover;">
      </div>
    </div>

  </section>End Hero -->
<div id="banner">
    <div class="container-fluid p-0">
      <div class="d-none d-md-block">
        <img src="<?php echo e(asset('frontend/assets/img/banner/home-bannwer-web.png')); ?>" class="img-fluid">
      </div>
      <div class="d-md-none d-sm-block">
        <img src="<?php echo e(asset('frontend/assets/img/banner/home-banner-mobile.png')); ?>" class="img-fluid">
      </div>
    </div>
    
</div><!-- End Hero -->

  <main id="main">

    <!-- ======= Featured Services Section ======= -->
    <section id="featured-services" class="featured-services pt-5">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h5 class="text-center text-white">Checkout Our Services</h5>
            <div style="width:250px; height: 1px; background: #ffffff; margin: auto;"></div>
          </div>
          <div class="col-md-12">
            <h1 class="text-center text-white"><b>What we’re offering</b></h1>
          </div>
          <div class="col-md-12">
            <h5 class="text-center text-white">We Ensure Only Quality Services for our Clients</h5>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-4 col-md-6">
            <div class="offering pt-5">
              
              <div class="card web-card">
                <div style="height: 234px; display: flex;">
                   <img src="<?php echo e(asset('frontend/assets/img/Laptop.png')); ?>" class="card-img-top" alt="...">
                </div>
                <div class="card-body">
                  <button class="my-4">Website Design</button>
                  <p class="card-text">Need your business website to be designed by us? We will be there with our best
                    IT
                    team.</p>
                  <div class="btn mt-4 mb-4">
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('services')); ?>" style="margin-left: -3px;"><i class="bi bi-arrow-right"></i></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" style="margin-left: -3px;"><i class="bi bi-arrow-right"></i></a>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div class="col-lg-4 col-md-6">
            <div class="offering pt-5">
              
              <div class="card web-card">
                <div style="height: 234px; display: flex;">
                  <img src="<?php echo e(asset('frontend/assets/img/Mobile.png')); ?>" class="card-img-top" >
                </div>
                <div class="card-body">
                  <button class="my-4">Mobile App</button>
                  <p class="card-text">Our best IT team will be there to give you quality & smooth app to run your
                    business and easily get connected with customers.</p>
                  <div class="btn mt-4 mb-4">
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('services')); ?>" style="margin-left: -3px;"><i class="bi bi-arrow-right"></i></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" style="margin-left: -3px;"><i class="bi bi-arrow-right"></i></a>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6">
            <div class="offering pt-5">
              
              <div class="card web-card">
                <img src="<?php echo e(asset('frontend/assets/img/Shop.png')); ?>" class="card-img-top" alt="..." style="height:234px">
                <div class="card-body">
                  <button class="my-4">Agent Portal, Face to Face terminal Card</button>
                  <p class="card-text">An efficient portal will help you to track your database easily, get your data
                    store easily.</p>
                  <div class="btn mt-4 mb-4">
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('services')); ?>" style="margin-left: -3px;"><i class="bi bi-arrow-right"></i></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" style="margin-left: -3px;"><i class="bi bi-arrow-right"></i></a>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Featured Services Section -->

    <!-- ======= About Us Section ======= -->
    <section id="about" class="home-about mt-3">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 ">
            <h1 class="text-white">Become An Agent</h1>
            <p>
              Joining Worldwide network could offer your business significant advantage and give you the growth you’ve
              been seeking. Becoming an Agent is a simple and easy process and we offer you constant support every step
              of the way.
            </p>
            <a href="<?php echo e(route('login')); ?>" style="display: flex; justify-content:center;"><button>Call us today</button></a>
          </div>
          <div class="col-lg-6 pt-4 ">
            <div class="content">
              <h1>Don’t Lose time! Join Us and we will help <br> your business to become Digital <br> powered by
                WORLDWIDE SERVICES</h1>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End About Us Section -->
    <!-- ======= About Us Section ======= -->
    <section id="apps" class="apps bg-white"
      style="background: url(assets/img/ellipse-bg.svg); background-repeat: no-repeat;background-position: right;">
      <div class="container">

        <div class="row">
          <div class="col-lg-6 col-md-6 ">
            <img src="<?php echo e(asset('frontend/assets/img/Mobile-Set3.png')); ?>" class="img-fluid" style="height: 450px; width:450px;object-fit:contain;">
          </div>
          <div class="col-lg-6 col-md-6 pt-4">
            <div class="app-section">
              <h3 class="p-3 text-center mt-5"><b>Get your app ready for your business!</b></h3>
              <p class="p-3" style="color: rgba(0, 0, 0, 0.5);">
                Would you like to provide your customer an efficient, smooth, easily accessible mobile app? Get it done
                easily by our experts! We are there to help you to get the best version for your business! Consult with
                us we will make it easy for you.
              </p>
              <div class="row">
                <div class="col-md-12 text-center">
                  <strong style="color: rgba(0, 0, 0, 0.5);">We Provide the app to your both versions</strong>
                </div>
                <div class="col-md-6 pt-4 text-lg-end  text-center">
                  <a href=""><img src="<?php echo e(asset('frontend/assets/img/googleplay.png')); ?>" class="img-fluid" width="200"></a>
                </div>
                <div class="col-md-6 pt-4  text-center">
                  <a href=""><img src="<?php echo e(asset('frontend/assets/img/apple.png')); ?>" class="img-fluid" width="200"></a>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->
    <!-- ======= Our Clients Section ======= -->
    <section id="clients" class="clients" style="background: #fff;">
      <div class="container">

        <div class="section-title">
          <h2 style="color: #52B2E3">Our Partners</h2>
        </div>

        <div class="clients-slider swiper">
          <div class="swiper-wrapper align-items-center">
            <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide"><img src="<?php echo e(asset ($partner->picture)); ?>" class="img-fluid" alt=""></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Our Clients Section -->
    <!-- ======= Our Clients Section ======= -->
    <section id="clients" class="clients" style="background: #fff;">
      <div class="container">

        <div class="section-title">
          <h2 style="color: #52B2E3">Our Payout Partners</h2>
        </div>

        <div class="clients-slider swiper">
          <div class="swiper-wrapper align-items-center">
            <?php $__currentLoopData = $payout_partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payout_partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide"><img src="<?php echo e(asset ($payout_partner->picture)); ?>" class="img-fluid" alt=""></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Our Clients Section -->


    <!-- ======= Cta Section ======= -->
  <!--   <section id="cta" class="cta">
      <div class="container">

        <div class="row">
          <div class="col-lg-9 text-center text-lg-start">
            <h3>Consulting for taking our agentship</h3>
            <p>Consult us now!</p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle bg-white text-dark" href="#">Contact Us</a>
          </div>
        </div>

      </div>
    </section> --><!-- End Cta Section -->


  </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\worldwide\resources\views/frontend/index.blade.php ENDPATH**/ ?>