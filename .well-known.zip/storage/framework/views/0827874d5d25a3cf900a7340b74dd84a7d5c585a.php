<?php echo e($slot); ?>

<?php /**PATH /home/u17shag/public_html/worldwidesvc.com/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>