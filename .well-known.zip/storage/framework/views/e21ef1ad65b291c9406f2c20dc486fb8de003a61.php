<?php $__env->startSection('title', $title); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/assets/node_modules/summernote/dist/summernote-bs4.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <form method="POST" action="<?php echo e(route('admin.cookies.update')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
            <div class="card">
                <div class="card-header">
                    <button type="submit" class="btn btn-primary" style="float: right;">Update</button>
                    <?php echo e($title); ?> Update
                </div>
                <div class="card-body table-responsive">
                    <div class="form-group">
                        <textarea class="form-control" name="description" id="summernote"><?php echo $data->description; ?></textarea>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('backend/assets/node_modules/summernote/dist/summernote-bs4.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#data_table').DataTable();
        $('#summernote').summernote({
            height: 350, // set editor height
            minHeight: null, // set minimum height of editor
            maxHeight: null, // set maximum height of editor
            focus: false // set focus to editable area after initializing summernote
        });

    });
 </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\worldwide\resources\views/backend/pages/cookies_policy.blade.php ENDPATH**/ ?>