<?php echo e($slot); ?>

<?php /**PATH E:\worldwide\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>