

<!-- ======= Header ======= -->
<header id="header" class="fixed-top">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="contact-info d-flex align-items-center">

                </div>
                <ul class="nav d-flex justify-content-end topbar_margin">
                    <!--  <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"
            style="color: #000;">Language</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">English</a></li>
            <li><a class="dropdown-item" href="#">Spanish</a></li>
          </ul>
        </li> -->
                    <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button"
                            aria-expanded="false" style="color: #000;"><?php echo e(Auth::user()->first_name); ?>

                            <?php echo e(Auth::user()->last_name); ?></a>
                        <ul class="dropdown-menu">
                            <!-- <li><a class="dropdown-item" href="#">Profile</a></li> -->
                            <li><a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>">Logout</a></li>
                        </ul>
                    </li>
                    <?php else: ?>
                    <li class="nav-item me-2 pt-2">
                        <a class="nav-link join" href="<?php echo e(route('login')); ?>">Join Now</a>
                    </li>
                    <li class="nav-item pt-2">
                        <a class="nav-link sign_in" href="<?php echo e(route('login')); ?>" style="color: #000;">Sign in</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="container d-flex align-items-center" >

        <!-- <h1 class="logo me-auto"><a href="index.html">Green</a></h1> -->
        <!-- Uncomment below if you prefer to use an image logo -->
        <!--<a href="" class="logo me-auto"><img src="" alt="" class="img-fluid"-->
        <!--    height="50px"></a>-->
        <a href="<?php echo e(url('/')); ?>" class="logo me-auto"><img src="<?php echo e(asset('frontend/assets/img/logo/logo.png')); ?>" alt=""
                class="img-fluid"></a>



        <nav id="navbar" class="navbar">
            <ul>
                <li><a class="nav-link scrollto <?php echo $__env->yieldContent('home'); ?>" href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><a class="nav-link scrollto <?php echo $__env->yieldContent('services'); ?>" href="<?php echo e(route('services')); ?>">Services</a></li>
                <li><a class="nav-link scrollto <?php echo $__env->yieldContent('about'); ?>" href="<?php echo e(route('about')); ?>">About Us</a></li>
                <li><a class="nav-link scrollto <?php echo $__env->yieldContent('contact'); ?>" href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->

    </div>
</header><!-- End Header
<?php /**PATH /home/u17shag/public_html/worldwidesvc.com/resources/views/frontend/include/header.blade.php ENDPATH**/ ?>