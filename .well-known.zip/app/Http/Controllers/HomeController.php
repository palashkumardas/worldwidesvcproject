<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\Contact;
use App\Models\About;
use App\Models\PrivacyPolicy;
use App\Models\TermsConditions;
use App\Models\CookiesPolicy;
use App\Models\Partner;
use App\Models\PayoutPartner;

class HomeController extends Controller
{


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $partners = Partner::where('status', true)->get();
        $payout_partners = PayoutPartner::where('status', true)->get();
        // $contact = Contact::get()->first();
        return view('frontend.index', compact('partners','payout_partners'));
    }

    public function showRegistrationMessage()
    {
        return view('auth.register_first');
    }


    public function about()
    {
        $about = About::get()->first();
        return view('frontend.pages.about', compact('about')); 
    }

    
    public function contact()
    {
        $contact = Contact::get()->first();
        return view('frontend.pages.contact', compact('contact')); 
    }

        
    
    public function privacy()
    {
        $privacy = PrivacyPolicy::get()->first();
        return view('frontend.pages.privacy', compact('privacy'));
    }
        
    
    public function terms()
    {
        $terms = TermsConditions::get()->first();
        return view('frontend.pages.terms', compact('terms'));
    }        
    
    public function cookies()
    {
        $cookies = CookiesPolicy::get()->first();
        return view('frontend.pages.cookies', compact('cookies'));
    }
    public function career()
    {
        // $cookies = CookiesPolicy::get()->first();
        // return view('frontend.pages.career', compact('career'));
        return view('frontend.pages.career');
    }

    public function UserLogout(){
        Auth::logout();
        return Redirect('/');
    }

}
